package odev4;

public interface Avlanabilir {
	public void Avlan();
}
