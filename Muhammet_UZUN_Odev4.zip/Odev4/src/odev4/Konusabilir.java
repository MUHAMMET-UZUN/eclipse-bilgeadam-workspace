package odev4;

public interface Konusabilir {
	public void Konus();
}
