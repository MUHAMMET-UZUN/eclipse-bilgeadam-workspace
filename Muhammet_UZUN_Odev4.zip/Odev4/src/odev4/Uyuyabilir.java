package odev4;

public interface Uyuyabilir {
	public void Uyu();
}
