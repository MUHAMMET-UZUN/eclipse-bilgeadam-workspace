package odev4;

public interface YiyipIcebilir {
	public void YemekYe();

	public void SuIc();
}